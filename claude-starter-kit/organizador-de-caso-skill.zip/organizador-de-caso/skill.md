---
name: Organizador de Caso Jurídico
description: Organiza e consolida documentos de um processo ou arbitragem em uma pasta local, criando índice, detectando versões e buscando materiais em fontes conectadas.
---

# Objetivo

Use esta skill quando a usuária pedir para criar, organizar, atualizar ou completar a pasta de um caso, processo, arbitragem ou matter.

O objetivo é reunir o material relevante em UMA pasta de trabalho do caso, sem apagar originais e sem inventar documentos ausentes.

# Princípios obrigatórios

1. A pasta do caso é uma pasta de trabalho; o DMS oficial do escritório continua sendo a fonte oficial se existir.
2. Nunca delete arquivos.
3. Nunca sobrescreva arquivos existentes.
4. Por padrão, COPIE arquivos para a pasta do caso; não mova o original de outra localização.
5. Nunca renomeie um documento filed/signed sem preservar o nome original no índice.
6. Não presuma acesso a uma fonte. Antes de buscar, identifique quais fontes estão realmente conectadas nesta sessão.
7. Se um documento parecer privileged, altamente sensível ou fora do escopo do caso, sinalize antes de copiá-lo.
8. Quando não conseguir transferir um arquivo automaticamente (por exemplo, determinado anexo de email), crie uma lista clara para download manual.

# Estrutura simples da pasta

Dentro da pasta raiz do caso, use:

00_INBOX_TO_SORT/
01_PLEADINGS/
02_CONTRACTS_AND_KEY_DOCS/
03_EVIDENCE/
04_WITNESSES_AND_EXPERTS/
05_PROCEDURAL/
06_RESEARCH/
90_CLAUDE_OUTPUTS/
99_ARCHIVE/
CASE_INDEX.md

Não crie subpastas extras sem necessidade.

# Fluxo de trabalho

## 1. Entender o caso

Identifique, a partir do Project ou da instrução da usuária:
- nome curto do caso;
- cliente;
- parte adversa;
- número do processo/arbitragem, se houver;
- instituição/foro;
- nomes e aliases relevantes;
- intervalo aproximado de datas.

Se faltar informação indispensável para distinguir o caso de outros, faça uma única pergunta objetiva.

## 2. Inventariar o que já existe

Leia recursivamente a pasta do caso conectada no Cowork.
Crie ou atualize CASE_INDEX.md com:
- caminho do arquivo;
- nome do arquivo;
- data aparente;
- tipo de documento;
- parte/autor;
- status: WORKING / FINAL / FILED / SIGNED / UNKNOWN;
- tema/issue, quando evidente;
- possível duplicata;
- observações.

## 3. Organizar o INBOX

Para arquivos em 00_INBOX_TO_SORT:
- identifique o tipo;
- proponha a pasta de destino;
- detecte duplicatas e versões;
- copie/organize sem sobrescrever;
- preserve originais quando houver dúvida.

Use estes destinos:
- pleadings/submissions -> 01_PLEADINGS
- contratos, aditivos, notices essenciais -> 02_CONTRACTS_AND_KEY_DOCS
- emails, correspondências e demais evidências -> 03_EVIDENCE
- witness statements, expert reports e materiais por testemunha/expert -> 04_WITNESSES_AND_EXPERTS
- procedural orders, termos de arbitragem, calendário, comunicações do tribunal -> 05_PROCEDURAL
- jurisprudência, doutrina e pesquisa -> 06_RESEARCH
- tudo produzido pelo Claude -> 90_CLAUDE_OUTPUTS
- documentos antigos/superseded -> 99_ARCHIVE, mas somente quando isso estiver claro.

## 4. Procurar documentos fora da pasta

Quando a usuária disser para reunir documentos espalhados, procure SOMENTE nas fontes às quais Claude possui acesso nesta sessão.

### Pastas locais / HD
Se a usuária conectou pastas locais adicionais:
- pesquise por nomes das partes, número do caso, instituição, nomes de testemunhas e palavras-chave específicas;
- apresente primeiro uma lista de candidatos;
- quando a instrução for consolidar, copie os arquivos pertinentes para 00_INBOX_TO_SORT;
- não delete nem mova o original.

### Outlook / Microsoft 365
Se o conector Microsoft 365 estiver disponível:
- pesquise emails por nomes das partes, domínio, assunto, número do caso e intervalo de datas;
- identifique emails potencialmente relevantes;
- inclua remetente, destinatários, data, assunto e razão da relevância no índice de intake;
- identifique anexos mencionados ou disponíveis;
- se o ambiente não permitir salvar o anexo original diretamente na pasta local, crie `90_CLAUDE_OUTPUTS/EMAIL_ATTACHMENTS_TO_DOWNLOAD.md` com uma checklist contendo email, data, assunto, nome do anexo e motivo para baixar.

### OneDrive / SharePoint
Se o conector Microsoft 365 estiver disponível:
- pesquise arquivos relevantes por nome, partes, case number e termos específicos;
- não copie cegamente tudo;
- liste candidatos e sua localização de origem;
- se for necessário manter cópia local e a transferência direta não estiver disponível, inclua-os em `90_CLAUDE_OUTPUTS/FILES_TO_COPY.md`.

## 5. Evitar lixo e duplicatas

Antes de adicionar um arquivo:
- compare nome, tamanho, data e conteúdo quando possível;
- identifique versões anteriores;
- prefira FINAL/FILED/SIGNED como referência, sem apagar WORKING;
- não deixe três cópias idênticas em pastas diferentes.

## 6. Finalizar cada rodada

Ao terminar, entregue um resumo curto:
- documentos encontrados;
- documentos novos adicionados;
- duplicatas identificadas;
- itens que exigem download manual;
- arquivos cuja classificação está incerta;
- possíveis lacunas do caso;
- próxima ação recomendada.

Atualize CASE_INDEX.md.

# Exemplo de pedido que deve ativar esta skill

"Organize a pasta do caso Acme v. Beta. Procure o que já está no meu HD e, se o Microsoft 365 estiver conectado, procure também no Outlook/OneDrive/SharePoint. Quero reunir os documentos do caso nesta pasta sem apagar os originais."
